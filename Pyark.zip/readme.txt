如果驱动加载失败，可以把C:\Windows\System32\drivers\PYArkSafe.sys拷贝到exe同级目录改名为PYArkSafe64.sys,然后自己给驱动文件签名.
If the driver fails to load, you can copy C: \ Windows \ System32 \ drivers \ PYArkSafe.sys to the same level directory of exe and rename it to PYArkSafe64.sys, and then sign the driver file yourself
