如果加载失败提示 loaddriver failed，可以将系统盘符比如c:\windows\system32\driver\PYArkSafe.sys复制到exe根目录下 改名为PYArkSafe64.sys并且自己签名


If the prompt "loaddriver failed" appears when loading fails, you can set the system drive letter, such as C: \ windows \ system32\drivers\pyarksafe.Sys to the root directory of exe, rename it pyarksafe64.sys, and sign it yourself

